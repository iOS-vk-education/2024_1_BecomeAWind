import SwiftUI
import FirebaseAuth

struct RegisterView: View {
    var body: some View {
        Button {
            Auth.auth().createUser(withEmail: "email@email.com", password: "123") { authResult, error in
                if error == nil {
                    
                }
            }
        } label: {
            YCapsuleLabel(title: "создать аккаунт", font: FontManager.getFont(with: .bold, and: 17))
        }
    }
}

#Preview {
    RegisterView()
}
